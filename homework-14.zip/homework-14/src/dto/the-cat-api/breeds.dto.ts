export interface BreedDto {
    id: number;
    name: string;
    weight: string | null;
    height: string | null;
    life_span: string;
    breed_group: string;
}
