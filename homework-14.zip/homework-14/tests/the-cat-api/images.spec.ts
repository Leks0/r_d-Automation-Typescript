import { describe, test, expect } from 'vitest';
import { ConfigService } from 'src/services/config.service';
import { FetchApiService } from 'src/services/fetch-api.service';
import { ImagesApi } from 'src/apis/the-cat-api/images.api';


describe('TheCatAPI Images Tests', () => {
    const configService = new ConfigService();
    const config = configService.getConfig();
    const fetchApi = new FetchApiService(config.api.baseUrl, { apiKey: config.auth.apiKey});
    const imagesApi = new ImagesApi(fetchApi);
    const context : Record<string, unknown> = {};

    describe('Get images', () => {
        test('imageSearch', async () => {
            const [response] = await imagesApi.imageSearch();

            expect(response.status).toBeOneOf([200, 201]);
        });
    });

    describe('Upload image', () => {
        test('Upload Image test', async () => {
            const [response, image] = await imagesApi.imageUpload('pictures/71.jpg', 'VILE');

            expect(response.status).toBeOneOf([200, 201]);
            expect(image.id).toBeDefined();

            context.imageId = image.id;
        });
    });
});
